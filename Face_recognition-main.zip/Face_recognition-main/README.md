# Face_recognition
Using Python, OpenCV, Tkinter, and more to face recognition system.
